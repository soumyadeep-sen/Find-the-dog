<?php
require 'connection.php';
if(isset($_POST['api-key'])){
    $api_key = $_POST['api-key'];
    if($api_key == "12345"){
        if(isset($_POST['instructor_id'])){
            $id = $_POST['instructor_id'];            
            if(isset($_POST['player_id'])){
                $player = $_POST['player_id'];
                $result = mysqli_query($con,"SELECT * FROM instructor WHERE instructor_id=$id");
                $row = mysqli_fetch_row($result);
                $result1 = mysqli_query($con,"SELECT * FROM player WHERE instructor_id=$id");
                $row1 = mysqli_fetch_row($result1);
                if($row && !$row1){
                    mysqli_query($con,"INSERT IGNORE INTO player(player_id,instructor_id) values($player,$id)");
                    mysqli_query($con,"UPDATE instructor SET connected_player = $player WHERE instructor_id = $id");
                    echo 'Connected.';
                }else if($row1){
                    echo 'Room is occupied.';
                }else{
                    echo 'Room not found.';
                }
            }else if(isset($_POST['room_id'])){
                $room = $_POST['room_id'];
                $result = mysqli_query($con,"SELECT * FROM instructor WHERE instructor_id=$id");
                $row = mysqli_fetch_assoc($result);
                if($row['connected_player'] != 0){
                    mysqli_query($con,"UPDATE instructor SET selected_room = '$room',player_status = '' WHERE instructor_id=$id");
                    echo $room;
                }else{
                    echo 'Waiting for player to connect.';
                }
            }else if(isset($_POST['player_status'])){
                $player_status = $_POST['player_status'];
                mysqli_query($con,"UPDATE instructor SET player_status = '$player_status' WHERE instructor_id=$id");
            }else{
                mysqli_query($con,"DELETE FROM instructor WHERE TIMESTAMPDIFF(MINUTE,created_at,NOW()) > 120");
                mysqli_query($con,"INSERT IGNORE INTO instructor(instructor_id) values($id)");
            }
            mysqli_close($con);
        }
    }
}