var domain = "https://smdp91s.000webhostapp.com/";

// ----- Google Speech Recognition -------

var recognition = new webkitSpeechRecognition();
final_transcript = '';
recognition.continuous = true;
recognition.interimResults = true;

recognition.onstart = function () { }

recognition.onresult = function (event) {
    var interim_transcript = '';

    for (var i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
            final_transcript += event.results[i][0].transcript;
        } else {
            interim_transcript += event.results[i][0].transcript;
        }
    }
    final_transcript = final_transcript.toLowerCase();
    console.log("final_transcript---" + final_transcript);
    final_transcript = '';
}
recognition.onerror = function (event) { }
recognition.onend = function () { recognition.start(); }


// ----- Bing Text Speech-------

var bingClientTTS = new BingSpeech.TTSClient("7fb280955c684ae5a363377ae6a490b3");



// ----- Set rooms --------

function Room(floor, color, purpose, livesin, name, id) {

    this.floor = floor;

    this.color = color;

    this.purpose = purpose;

    this.livesin = livesin;

    this.name = name;

    this.id = id;

}

var rooms = [];

rooms.push(new Room(3, 'yellow', 'Where your Mom sleeps', 'Mom and Dad sleep there.', "Bedroom", 'bedroom'));

rooms.push(new Room(3, 'pink', 'Where your Mom stores clothes', 'Nobody lives there.', "Closet", 'closet'));

rooms.push(new Room(2, 'green', 'Where your Sister study', 'Sister sleeps there.', "Sister's room", 'sister_room'));

rooms.push(new Room(2, 'blue', 'Where your Brother study', 'Brother sleeps there.', "Brother's room", 'brother_room'));

rooms.push(new Room(1, 'orrange', 'Where your mom cooks', 'Nobody lives there.', 'kitchen', 'kitchen'));

rooms.push(new Room(1, 'white', 'Where you eat dinner', 'Nobody lives there.', 'Dining room', 'dining'));

rooms.push(new Room(1, 'yellow', 'Where you brush your teeth', 'Nobody lives there.', 'bathroom', 'bathroom'));

rooms.push(new Room(0, 'pink', 'Where you watch cartoon.', 'You watch TV there.', "Drawing room", 'drawing'));

rooms.push(new Room(0, 'grey', 'Where your Dad park the car.', 'Nobody lives there.', "Garage", 'garage'));



function getRandomRoom() {

    return rooms[Math.floor(Math.random() * rooms.length)];

}

var DogHidden = false;

var DogFound = false;

var currentRoom = null;

$("#instructor-btn").click(function () {
    $("#instructor-btn").attr('disabled', 'true');
    localStorage.setItem('player', 'instructor');

    var instructor_id = SixDigitRandomNumber();

    localStorage.setItem('roomid', instructor_id);

    console.log(instructor_id);

    $.ajax({

        url: domain + 'insert.php',

        type: 'POST',

        data: { 'api-key': '12345', 'instructor_id': instructor_id },

        success: function (data) {

            if (data !== null) {
                location.replace('index.html?player=' + localStorage.getItem('player') + '&roomid=' + data);
            }

        },

        error: function () {

            alert("Disconnected");

        }

    });
});
if (location.search.includes('player=instructor')) {

    document.getElementById("backmusic").pause();
    $('#setting').hide();
    $("#backdiv,#ModeSelection,#TypeSelection,#SetInstructor,#wall").hide();

    localStorage.setItem('player', 'instructor');

    if (!location.search.includes("roomid=")) {

        var instructor_id = SixDigitRandomNumber();

        localStorage.setItem('roomid', instructor_id);

        location.replace('index.html?player=' + localStorage.getItem('player') + '&roomid=' + instructor_id);

    } else {

        var a = location.search.substring(1, location.search.length).split('&');

        a.forEach(element => {
            e = element.split('=');
            if (e[0] === 'roomid') {
                localStorage.setItem('roomid', e[1]);
            }
        });

        var instructor_id = localStorage.getItem('roomid');

        $.ajax({

            url: domain + 'insert.php',

            type: 'POST',

            data: { 'api-key': '12345', 'instructor_id': instructor_id },

            success: function () {

                $('#dialogue').html("Select a room.");
                $('#dialogue').fadeIn(200).delay(10000).fadeOut(200);

            },

            error: function () {

                alert("Disconnected");

            }

        });

        $('.fake-div').click(function () {

            if ($(this).html() === '') {
                $('.fake-div').hide();

                $.ajax({

                    url: domain + 'insert.php',

                    type: 'POST',

                    data: { 'api-key': '12345', 'instructor_id': instructor_id, 'room_id': this.id },

                    success: function (data) {

                        if (data !== null) {

                            if (data === "Waiting for player to connect.") {

                                $('#dialogue').html("Waiting for player to connect.");

                                $('#dialogue').fadeIn(200).delay(3000).fadeOut(200);

                                $('.fake-div').show();

                            } else {

                                rooms.forEach(function (room) {

                                    if (room.id === data) {

                                        $('#dialogue').html(room.name + ' selected.');

                                        $('#dialogue').fadeIn(200).delay(3000).fadeOut(200);

                                    }

                                });

                                getPlayerStatus();

                            }

                        }

                    },

                    error: function () {

                        alert("Disconnected");

                    }

                });
            }
        });

        function getPlayerStatus() {

            $.ajax({

                url: domain + 'fetch.php',

                type: 'POST',

                data: { 'api-key': '12345', 'instructor_id': instructor_id },

                success: function (data) {

                    if (data !== null) {

                        var json = JSON.parse(data);

                        if (json !== null && json.player_status === "success") {

                            $('.fake-div').html('');
                            $('.fake-div').show();

                            $('#dialogue').html("Player got it right. Select another room.");

                            $('#dialogue').fadeIn(200).delay(5000).fadeOut(200);

                            bingClientTTS.synthesize("Player got it right. Select another room.");

                        } else if (json !== null && json.player_status === '') {

                            console.log("getPlayerStatus");

                            getPlayerStatus();

                        } else {

                            $.ajax({

                                url: domain + 'insert.php',

                                type: 'POST',

                                data: { 'api-key': '12345', 'instructor_id': instructor_id, 'player_status': '' },

                                success: function () {

                                    $('#dialogue').html("Player got it wrong.");

                                    $('#dialogue').fadeIn(200).delay(5000).fadeOut(200);

                                    bingClientTTS.synthesize("Player got it wrong.");

                                    $('.fake-div').html('');
                                    $('.fake-div').hide();

                                    $('#' + json.player_status).html("<div align='center' class='row'><span class='fa fa-times fa-4x' style='color:red;margin-top:3vmin;'></span></div>");
                                    $('#' + json.player_status).show();

                                    getPlayerStatus();

                                },

                                error: function () {

                                    alert("Disconnected");

                                }

                            });

                        }

                    }

                },

                error: function () {

                    alert("Disconnected");

                }

            });

        }
    }
} else if (location.search.includes("player=two")) {

    document.getElementById("backmusic").pause();
    $('#setting').hide();

    $("#ModeSelection,#TypeSelection").hide();
    localStorage.setItem('player', 'two');

    if (location.search.includes("roomid=")) {
        var a = location.search.substring(1, location.search.length).split('&');
        a.forEach(element => {
            e = element.split('=');
            if (e[0] === 'roomid') {
                localStorage.setItem('room', e[1]);
                $('#instructor_id').val(e[1]);

                var val = e[1];

                if (check_instructor_id(val)) {

                    $(this).attr('disabled', 'true')

                    $(this).html("Connecting..<i class='fa fa-refresh fa-spin fa-fw'></i>");

                    var newplayer = SixDigitRandomNumber();

                    $.ajax({

                        url: domain + 'insert.php',

                        type: 'POST',

                        data: { 'api-key': '12345', 'instructor_id': val, 'player_id': newplayer },

                        success: function (data) {

                            $('#connect').removeAttr("disabled");

                            $('#connect').html("<i class='fa fa-plug fa-fw'></i>CONNECT");

                            if (data !== null) {

                                if (data === 'Connected.') {

                                    $('#backdiv,#SetInstructor').hide();

                                    getSelectedRoom();

                                } else if (data === 'Room not found.') {
                                    $('#connect').click();
                                }

                                $('#message').html(data);

                                $('#message').fadeIn(200).delay(3000).fadeOut(200);

                            }

                        },

                        error: function () {

                            alert("Disconnected");

                        }

                    });

                }
            }
        });
    }



    var loop = 0;

    var interval = null;


    function getSelectedRoom() {

        var val = $('#instructor_id').val();

        $.ajax({

            url: domain + 'fetch.php',

            type: 'POST',

            data: { 'api-key': '12345', 'instructor_id': val },

            success: function (data) {

                if (data !== null) {

                    var json = JSON.parse(data);

                    if (json !== null && json.selected_room !== "") {

                        $('#message').fadeOut();

                        rooms.forEach(function (room) {

                            if (room.id === json.selected_room) {

                                currentRoom = room;

                            }

                        });

                        console.log(json);

                        interval = setInterval(function () {

                            loop++;

                            if (!DogHidden) {

                                if (loop === 2) {

                                    //$('#girl').attr('src', 'images/girl_throwing_ball.gif');

                                }

                                if (loop === 3) {

                                    $('#ballWrapper').addClass('moveball');

                                }

                                if (loop === 4) {

                                    document.getElementById("puppy-bark").play();

                                    //$('#girl').attr('src', 'images/girl_idle.gif');

                                    $('#dog').attr('src', 'images/dog-run1.gif');

                                    $('#dog').addClass('run');

                                }

                                if (loop === 10) {

                                    $('#dog').hide();

                                    $('#dog').removeClass('run');

                                    DogHidden = true;

                                    loop = 0;

                                }

                            } else {

                                if (!DogFound) {

                                    if (loop === 1) {

                                        $('#dialogue').fadeIn(200).delay(3000).fadeOut(200);

                                        bingClientTTS.synthesize("Find the dog!");

                                        $('#wall').fadeOut(200);

                                    }

                                } else {

                                    if (loop === 5) {

                                        $('#' + currentRoom.id).html('');

                                        $('#dog').attr('src', 'images/dog-run2.gif');

                                        $('#dog').addClass('comeback');

                                        $('#wall').fadeIn(200);

                                        $('#dog').show();

                                        $('.fake-div').css({ 'z-index': 0 });

                                    }

                                    if (loop === 11) {

                                        $('#dog').removeClass('comeback');

                                        $('#dog').attr('src', 'images/dog.gif');

                                        $('#ballWrapper').removeClass('moveball');

                                        DogHidden = false;

                                        DogFound = false;

                                        loop = 0;

                                        clearInterval(interval);

                                        $.ajax({

                                            url: domain + 'insert.php',

                                            type: 'POST',

                                            data: { 'api-key': '12345', 'instructor_id': val, 'player_status': 'success' },

                                            success: function () {

                                                $.ajax({

                                                    url: domain + 'insert.php',

                                                    type: 'POST',

                                                    data: { 'api-key': '12345', 'instructor_id': val, 'room_id': '' },

                                                    success: function (data) {

                                                        getSelectedRoom();

                                                    },

                                                    error: function () {

                                                        alert("Disconnected");

                                                    }

                                                });

                                            },

                                            error: function () {

                                                alert("Disconnected");

                                            }

                                        });



                                    }

                                }

                            }

                        }, 1000);

                    } else {

                        console.log("Waiting for instructor.");

                        getSelectedRoom();

                    }

                }

            },

            error: function () {

                alert("Disconnected");

            }

        });

    }



    $('#connect').click(function () {

        var val = $('#instructor_id').val();

        if (check_instructor_id(val)) {

            $(this).attr('disabled', 'true')

            $(this).html("Connecting..<i class='fa fa-refresh fa-spin fa-fw'></i>");

            var newplayer = SixDigitRandomNumber();

            $.ajax({

                url: domain + 'insert.php',

                type: 'POST',

                data: { 'api-key': '12345', 'instructor_id': val, 'player_id': newplayer },

                success: function (data) {

                    $('#connect').removeAttr("disabled");

                    $('#connect').html("<i class='fa fa-plug fa-fw'></i>CONNECT");

                    if (data !== null) {

                        if (data === 'Connected.') {

                            $('#backdiv,#SetInstructor').hide();

                            getSelectedRoom();

                        } else if (data === 'Room not found.') {
                            $('#connect').click();
                        }

                        $('#message').html(data);

                        $('#message').fadeIn(200).delay(3000).fadeOut(200);

                    }

                },

                error: function () {

                    alert("Disconnected");

                }

            });

        }

    });

    function check_instructor_id(val) {

        var str = /^\d+$/;

        if (val !== "" && str.test(val)) {

            $('#instructor_id').closest('.input-group').removeClass('has-error').addClass('has-success');

            return true;

        } else {

            $('#instructor_id').closest('.input-group').removeClass('has-success').addClass('has-error');

            return false;

        }

    }

    $('.fake-div,#garage_car').click(function () {

        if (currentRoom === null) {

            $('#message').html("Waiting for instructor.");

            $('#message').fadeIn(200).delay(3000).fadeOut(200);

        }

        if (DogHidden && !DogFound) {

            $('.fake-div').html('');

            var fakeID = this.id;

            if (fakeID.includes(currentRoom.id)) {

                console.log("success");

                $('#' + currentRoom.id).html($('#checkmark').html());

                $('#' + currentRoom.id).css({ 'z-index': 20 });

                document.getElementById("puppy-bark").play();

                bingClientTTS.synthesize("Great! The dog was in the " + currentRoom.name);

                DogFound = true;

                $('#message').html("Great! The dog was in the " + currentRoom.name);

                $('#message').fadeIn(200).delay(5000).fadeOut(200);

                loop = 0;



            } else {

                console.log("wrong" + fakeID);

                var val = $('#instructor_id').val();

                $.ajax({

                    url: domain + 'insert.php',

                    type: 'POST',

                    data: { 'api-key': '12345', 'instructor_id': val, 'player_status': fakeID },

                    success: function () {



                    },

                    error: function () {

                        alert("Disconnected");

                    }

                });

                rooms.forEach(function (room) {


                    if (room.id === fakeID) {

                        $('#message').html("Wrong! he is not in " + room.name);

                        $('#message').fadeIn(200).delay(3000).fadeOut(200);

                        bingClientTTS.synthesize("Wrong! he is not in " + room.name);

                    }

                });

                $(this).html("<div align='center' class='row'><span class='fa fa-times fa-4x' style='color:red;margin-top:3vmin;'></span></div>");

            }

        }

    });

} else if (location.search.includes('player=single')) {

    $("#backdiv,#ModeSelection,#TypeSelection,#SetInstructor").hide();

    localStorage.setItem('player', 'single');

    var loop = 0;

    setInterval(function () {

        loop++;

        if (!DogHidden) {

            if (loop === 12) {

                //$('#girl').attr('src', 'images/girl_throwing_ball.gif');



            } else if (loop === 14) {

                document.getElementById("puppy-bark").play();

                $('#ballWrapper').addClass('moveball');

                //$('#girl').attr('src', 'images/girl_idle.gif');

                $('#dog').attr('src', 'images/dog-run1.gif');

                $('#dog').addClass('run');



            } else if (loop === 20) {

                $('#dog').hide();

                $('#dog').removeClass('run');

                DogHidden = true;

                currentRoom = getRandomRoom();

                loop = 0;

            }

        } else {

            if (!DogFound) {

                if (loop === 1) {

                    $('#dialogue').fadeIn(200).delay(3000).fadeOut(200);

                    bingClientTTS.synthesize('Find the dog!');

                    $('#wall').fadeOut(200);

                } else if (loop === 5) {

                    $('#message').html("Where is the dog?");

                    $('#message').fadeIn(200).delay(3000).fadeOut(200);

                    bingClientTTS.synthesize('Where is the dog?');

                } else if (loop === 9) {

                    var sampleRooms = ['Bedroom', 'Kitchen', 'Garage', 'Closet', 'Dining room', "Sister's room", "Brother's room", 'Drawing room'];

                    var sampleRoom1 = sampleRooms[Math.floor(Math.random() * sampleRooms.length)];

                    var index = sampleRooms.indexOf(sampleRoom1);

                    if (index > -1) {

                        sampleRooms.splice(index, 1);

                    }

                    var sampleRoom2 = sampleRooms[Math.floor(Math.random() * sampleRooms.length)];



                    $('#message').html("Is he in the " + sampleRoom1 + ", or is he in the " + sampleRoom2 + "?");

                    $('#message').fadeIn(200).delay(3000).fadeOut(200);

                    bingClientTTS.synthesize('Is he in the ' + sampleRoom1 + ', or is he in the ' + sampleRoom2 + '?');

                } else if (loop === 16) {

                    $('#message').html("The dog is in the room " + currentRoom.purpose);

                    $('#message').fadeIn(200).delay(5000).fadeOut(200);

                    bingClientTTS.synthesize("The dog is in the room " + currentRoom.purpose);

                    recognition.start();

                } else if (loop === 26) {

                    $('#message').html("The dog is in the room with " + currentRoom.color + " walls.");

                    $('#message').fadeIn(200).delay(5000).fadeOut(200);

                    bingClientTTS.synthesize("The dog is in the room with " + currentRoom.color + " walls.");

                } else if (loop === 36) {

                    $('#message').html("The dog is hiding in the " + currentRoom.name);

                    $('#message').fadeIn(200).delay(5000).fadeOut(200);

                    bingClientTTS.synthesize("The dog is hiding in the " + currentRoom.name);

                }

            } else {

                if (loop === 5) {

                    $('#' + currentRoom.id).html('');

                    $('#dog').attr('src', 'images/dog-run2.gif');

                    $('#dog').addClass('comeback');

                    $('#wall').fadeIn(200);

                    $('#dog').show();

                    $('.fake-div').css({ 'z-index': 0 });

                }

                if (loop === 11) {

                    $('#dog').removeClass('comeback');

                    $('#dog').attr('src', 'images/dog.gif');

                    $('#ballWrapper').removeClass('moveball');

                    DogHidden = false;

                    DogFound = false;

                    loop = 0;

                }

            }

        }

    }, 1000);



    $("body").click(function () {

        if (loop < 11 && !DogHidden) {

            loop = 11;

        }

    });



    $('.fake-div,#garage_car').click(function () {

        if (DogHidden && !DogFound && loop > 16) {

            $('.fake-div').html('');

            var fakeID = this.id;

            if (fakeID.includes(currentRoom.id)) {

                console.log("success");

                $('#' + currentRoom.id).html($('#checkmark').html());

                $('#' + currentRoom.id).css({ 'z-index': 20 });

                document.getElementById("puppy-bark").play();

                bingClientTTS.synthesize("Great! The dog was in the " + currentRoom.name);

                DogFound = true;

                $('#message').html("Great! The dog was in the " + currentRoom.name);

                $('#message').fadeIn(200).delay(5000).fadeOut(200);

                loop = 0;

            } else {

                console.log("wrong");
                if (this.id === 'garage_car') {
                    fakeID = 'garage';
                }

                rooms.forEach(function (room) {

                    console.log(room.id + "   " + fakeID);

                    if (room.id === fakeID) {

                        $('#message').html("Wrong! he is not in " + room.name);

                        $('#message').fadeIn(200).delay(3000).fadeOut(200);

                        bingClientTTS.synthesize("Wrong! he is not in " + room.name);

                    }

                });

                $('#' + fakeID).html("<div align='center' class='row'><span class='fa fa-times fa-4x' style='color:red;margin-top:3vmin;'></span></div>");

                if (loop > 36) {

                    loop = 10;

                }

            }

        }

    });

}



document.getElementById("backmusic").volume = 0.5;

$('#music').change(function () {

    if (!$(this).prop('checked')) {

        document.getElementById("backmusic").pause();

    } else {

        document.getElementById("backmusic").play();

    }

});

$('button').click(function () {

    if ($('#sound').prop('checked')) {

        document.getElementById("buttonclick").play();

    }

});

$('#garage_car').click(function () {

    if ($('#sound').prop('checked')) {

        document.getElementById("car-beep").play();

    }

});

$('.fake-div').click(function () {

    if ($('#sound').prop('checked')) {

        document.getElementById("teleport").play();

    }

});

function changeLanguage(language) {

    console.log(localStorage.getItem('player'));

    if (!location.search.includes(language)) {

        localStorage.setItem('language', language);

        location.replace('index.html?player=' + localStorage.getItem('player') + '&language=' + language);

    }

}

function SixDigitRandomNumber() {

    var number = Math.floor(Math.random() * 1000000);

    while (number.toString().length < 6) {

        number += '0';

    }

    return number;

}



$("#twoplayer").click(function () {

    $('#ModeSelection').fadeOut(200);

});

if (location.search.includes("player=")) {

    window.onbeforeunload = function (e) {

        var dialogText = 'Data will be lost if you leave the page, are you sure?';

        e.returnValue = dialogText;

        return dialogText;

    };

}