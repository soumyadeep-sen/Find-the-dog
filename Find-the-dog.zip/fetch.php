<?php
require 'connection.php';
if(isset($_POST['api-key'])){
    $api_key = $_POST['api-key'];
    if($api_key == "12345"){
        if(isset($_POST['instructor_id'])){
            $id = $_POST['instructor_id'];   
            $result = mysqli_query($con,"SELECT * FROM instructor WHERE instructor_id=$id");
            $row = mysqli_fetch_assoc($result);   
            echo json_encode($row);                  
            mysqli_close($con);
        }
    }
}